package com.util.service;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.util.model.AvailableRequest;
import com.util.model.RoomBookingDetailsReponse;
import com.util.model.UserBookingDetailsReponse;
import com.util.model.entity.RoomRegistrationEntity;
import com.util.model.entity.UserRegisterEntity;
import com.util.persistence.MeetingUserRepository;
import com.util.persistence.RoomRegistrationRepository;
import com.util.persistence.SlotRegistrationRepository;
import com.util.persistence.UserRegisterRepository;

@Service
public class AvailabilityServiceImpl implements AvailabilityService {

	@Autowired
	private SlotRegistrationRepository slotRepo;
	@Autowired
	private RoomRegistrationRepository roomRepo;
	@Autowired
	private UserRegisterRepository userRepo;
	@Autowired
	private MeetingUserRepository meetingRepo;

	@Override
	public List<String> getAvailableRooms(AvailableRequest request) throws Exception {
		List<Long> bookedRoomIdList = slotRepo.findRoomIdByDateAndInTimeAndOutTime(request.getDate(),
				request.getInTime(),request.getOutTime());

		List<RoomRegistrationEntity> roomDetailsList = roomRepo.findAll();
		List<String> availableRooms = null;
		if (Objects.nonNull(bookedRoomIdList)) {
			availableRooms = roomDetailsList.stream().filter(room -> !bookedRoomIdList.contains(room.getId()))
					.map(room -> room.getRoomName()).collect(Collectors.toList());
		} else {
			availableRooms = roomDetailsList.stream().map(room -> room.getRoomName()).collect(Collectors.toList());
		}

		return availableRooms;
	}

	@Override
	public List<String> getAvailableUsers(AvailableRequest request) throws Exception {
		List<UserRegisterEntity> userDetailsList = userRepo.findAll();
		List<Long> meetingIdList = slotRepo.findIdByDateAndInTimeAndOutTime(request.getDate(),
				request.getInTime(),request.getOutTime());
		List<String> availableUser = null;
		if (Objects.nonNull(meetingIdList)) {
			for (Long meetingId : meetingIdList) {
				List<String> userList = meetingRepo.findUserNameByMeetingId(meetingId);
				userDetailsList = userDetailsList.stream().filter(user -> !userList.contains(user.getUserName()))
						.collect(Collectors.toList());
			}
		}
		availableUser = userDetailsList.stream().map(user -> user.getUserName()).collect(Collectors.toList());
		return availableUser;
	}

	@Override
	public List<RoomBookingDetailsReponse> getBookedRoomsDetail() {
		LocalDate currentDate=LocalDate.now();

		return Optional.ofNullable(slotRepo.findByDateGreaterThanEqual(currentDate)).orElseGet(Collections::emptyList)
				.stream()
				.map(slot -> RoomBookingDetailsReponse.builder().date(slot.getDate()).inTime(slot.getInTime())
						.outTime(slot.getOutTime()).roomName(roomRepo.findRoomNameById(slot.getRoomId())).build())
				.collect(Collectors.toList());
	}

	@Override
	public List<UserBookingDetailsReponse> getBusyUsersDetail() {
		
		LocalDate currentDate = LocalDate.now();
		return Optional.ofNullable(slotRepo.findByDateGreaterThanEqual(currentDate)).orElseGet(Collections::emptyList)
				.stream()
				.map(slot -> UserBookingDetailsReponse.builder().date(slot.getDate()).inTime(slot.getInTime())
						.outTime(slot.getOutTime()).userList(meetingRepo.findUserNameByMeetingId(slot.getId())).build())
				.collect(Collectors.toList());
	}

}
