package com.util.service;

import com.util.model.RegisterUserRequest;

public interface RegisterationService {

	String addUser(RegisterUserRequest request);
	String addRoom(String request);
}
