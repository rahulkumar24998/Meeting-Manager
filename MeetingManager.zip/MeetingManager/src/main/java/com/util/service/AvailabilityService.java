package com.util.service;

import java.util.List;

import com.util.model.AvailableRequest;
import com.util.model.RoomBookingDetailsReponse;
import com.util.model.UserBookingDetailsReponse;

public interface AvailabilityService {

	List<String> getAvailableRooms(AvailableRequest request) throws Exception;
	List<String> getAvailableUsers(AvailableRequest request) throws Exception;
	
	List<RoomBookingDetailsReponse> getBookedRoomsDetail();
	List<UserBookingDetailsReponse> getBusyUsersDetail();
}
