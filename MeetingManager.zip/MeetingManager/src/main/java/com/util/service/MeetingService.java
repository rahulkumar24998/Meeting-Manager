package com.util.service;

import com.util.model.MeetingResponse;
import com.util.model.RoomMeetingRequest;
import com.util.model.StandaloneMeetingRequest;

public interface MeetingService {

	MeetingResponse oneToOneMeetingScheduler(StandaloneMeetingRequest request);
	MeetingResponse roomMeetingScheduler(RoomMeetingRequest request);
}
