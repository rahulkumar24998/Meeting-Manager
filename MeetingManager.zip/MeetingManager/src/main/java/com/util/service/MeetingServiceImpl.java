package com.util.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.util.exception.CustomException;
import com.util.model.AvailableRequest;
import com.util.model.MeetingResponse;
import com.util.model.RoomMeetingRequest;
import com.util.model.StandaloneMeetingRequest;
import com.util.model.entity.MeetingUserEntity;
import com.util.model.entity.SlotRegistrationEntity;
import com.util.persistence.MeetingUserRepository;
import com.util.persistence.RoomRegistrationRepository;
import com.util.persistence.SlotRegistrationRepository;

@Service
public class MeetingServiceImpl implements MeetingService {

	private static final String STATIC_MESSAGE = " is not available";
	@Autowired
	private AvailabilityService available;
	@Autowired
	private SlotRegistrationRepository slotRepo;
	@Autowired
	private MeetingUserRepository meetingRepo;
	@Autowired
	private RoomRegistrationRepository roomRepo;

	@Override
	public MeetingResponse oneToOneMeetingScheduler(StandaloneMeetingRequest request) {
		MeetingResponse response = new MeetingResponse();
		AvailableRequest availableRequst = AvailableRequest.builder().date(request.getDate())
				.inTime(request.getInTime()).outTime(request.getOutTime()).build();
		List<String> availableUsers = null;
		try {
			availableUsers = available.getAvailableUsers(availableRequst);
		} catch (Exception e) {
			throw new CustomException(e, "User Availability Exception");
		}
		if (Objects.nonNull(availableUsers) && !availableUsers.isEmpty()) {
			if (!availableUsers.contains(request.getOrganizer())) {
				response.setSuccess(false);
				response.setMessage(request.getOrganizer() + STATIC_MESSAGE);
			} else if (!availableUsers.contains(request.getAttendee())) {
				response.setSuccess(false);
				response.setMessage(request.getAttendee() + STATIC_MESSAGE);
			} else {
				oneToOneMeeting(request, response);
			}
		} else {
			response.setSuccess(false);
			response.setMessage("No User Available for this time slot");
		}

		return response;
	}

	private void oneToOneMeeting(StandaloneMeetingRequest request, MeetingResponse response) {
		SlotRegistrationEntity slotEntity = SlotRegistrationEntity.builder().date(request.getDate())
				.inTime(request.getInTime()).outTime(request.getOutTime()).roomId(0L).build();
		Long meetingId = saveSlot(slotEntity);
		List<MeetingUserEntity> meetingUserList = new ArrayList<>();
		MeetingUserEntity meetingUserOne = MeetingUserEntity.builder().meetingId(meetingId)
				.userName(request.getAttendee()).build();
		MeetingUserEntity meetingUserTwo = MeetingUserEntity.builder().meetingId(meetingId)
				.userName(request.getOrganizer()).build();
		meetingUserList.add(meetingUserOne);
		meetingUserList.add(meetingUserTwo);

		saveMeetingUserList(meetingUserList);

		response.setSuccess(true);
		response.setMeetingId(meetingId);
		response.setMessage("Meeting scheduled successfully");
	}

	@Override
	public MeetingResponse roomMeetingScheduler(RoomMeetingRequest request) {
		MeetingResponse response = new MeetingResponse();
		AvailableRequest availableRequst = AvailableRequest.builder().date(request.getDate())
				.inTime(request.getInTime()).outTime(request.getOutTime()).build();
		List<String> availableUsers = null;
		try {
			availableUsers = available.getAvailableUsers(availableRequst);
		} catch (Exception e) {
			throw new CustomException(e, "User Availability Exception");
		}
		List<String> availableRooms = null;
		try {
			availableRooms = available.getAvailableRooms(availableRequst);
		} catch (Exception e) {
			throw new CustomException(e, "Rooms Availability Exception");
		}
		if (Objects.nonNull(availableRooms) && !availableRooms.isEmpty()) {
			if (!availableRooms.contains(request.getRoomName())) {
				response.setSuccess(false);
				response.setMessage(request.getRoomName() + STATIC_MESSAGE);
			} else {
				if (Objects.nonNull(availableUsers) && !availableUsers.isEmpty()) {
					roomMeetingCheckAndScheduling(request, response, availableUsers);

				} else {
					response.setSuccess(false);
					response.setMessage("No User Available for this time slot");
				}
			}
		} else {
			response.setSuccess(false);
			response.setMessage("No Rooms Available for this time slot");
		}

		return response;
	}

	private void roomMeetingCheckAndScheduling(RoomMeetingRequest request, MeetingResponse response,
			List<String> availableUsers) {
		if (!availableUsers.contains(request.getOrganizer())) {
			response.setSuccess(false);
			response.setMessage(request.getOrganizer() + STATIC_MESSAGE);
			return;
		}
		for (String attendee : request.getUserList()) {
			if (!availableUsers.contains(attendee)) {
				response.setSuccess(false);
				response.setMessage(attendee + STATIC_MESSAGE);
				return;
			}
		}

		Long roomId = roomRepo.findIdByRoomName(request.getRoomName());
		SlotRegistrationEntity slotEntity = SlotRegistrationEntity.builder().date(request.getDate())
				.inTime(request.getInTime()).outTime(request.getOutTime()).roomId(roomId).build();
		Long meetingId = saveSlot(slotEntity);

		List<MeetingUserEntity> meetingUserList = request.getUserList().stream()
				.map(user -> MeetingUserEntity.builder().meetingId(meetingId).userName(user).build())
				.collect(Collectors.toList());

		MeetingUserEntity meetingUser = MeetingUserEntity.builder().meetingId(meetingId)
				.userName(request.getOrganizer()).build();
		meetingUserList.add(meetingUser);

		saveMeetingUserList(meetingUserList);

		response.setSuccess(true);
		response.setMeetingId(meetingId);
		response.setMessage("Meeting scheduled successfully");

	}

	@Transactional
	private void saveMeetingUserList(List<MeetingUserEntity> meetingUserList) {
		meetingRepo.saveAll(meetingUserList);

	}

	@Transactional
	private Long saveSlot(SlotRegistrationEntity slotEntity) {
		slotEntity = slotRepo.save(slotEntity);
		return slotEntity.getId();
	}

}
