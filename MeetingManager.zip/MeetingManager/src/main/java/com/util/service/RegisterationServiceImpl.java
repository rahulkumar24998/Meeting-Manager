package com.util.service;

import java.util.Objects;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.util.model.RegisterUserRequest;
import com.util.model.entity.RoomRegistrationEntity;
import com.util.model.entity.UserRegisterEntity;
import com.util.persistence.RoomRegistrationRepository;
import com.util.persistence.UserRegisterRepository;

@Service
public class RegisterationServiceImpl implements RegisterationService {

	@Autowired
	private UserRegisterRepository userRepo;
	@Autowired
	private RoomRegistrationRepository roomRepo;

	@Override
	@Transactional
	public String addUser(RegisterUserRequest request) {
		UserRegisterEntity userDetails = userRepo.findByUserName(request.getUserName());

		if (Objects.isNull(userDetails)) {
			UserRegisterEntity newUser = UserRegisterEntity.builder().userName(request.getUserName())
					.password(request.getPassword()).build();
			userRepo.save(newUser);

			return "User Registered Successfully";
		}

		return "User Already Exist";
	}

	@Override
	@Transactional
	public String addRoom(String request) {
		RoomRegistrationEntity roomDetails = roomRepo.findByRoomName(request);
		if (Objects.isNull(roomDetails)) {
			RoomRegistrationEntity newRoom = RoomRegistrationEntity.builder().roomName(request).build();
			roomRepo.save(newRoom);
			return "Room Registered Successfully";
		}

		return "Room is already Registered";
	}

}
