package com.util.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.util.model.AvailableRequest;
import com.util.model.MeetingResponse;
import com.util.model.UserBookingDetailsReponse;
import com.util.model.RegisterUserRequest;
import com.util.model.RoomBookingDetailsReponse;
import com.util.model.RoomMeetingRequest;
import com.util.model.StandaloneMeetingRequest;
import com.util.service.AvailabilityService;
import com.util.service.MeetingService;
import com.util.service.RegisterationService;

@RestController
@RequestMapping("/meeting")
public class MeetingController {

	@Autowired
	private RegisterationService register;
	@Autowired
	private AvailabilityService available;
	@Autowired
	private MeetingService meeting;
	
	
	@PostMapping(value = "/addUser", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> registerUser(
			@RequestBody(required = true) RegisterUserRequest request)
	{
		return  ResponseEntity.ok(register.addUser(request));
	}
	
	@PostMapping(value="/addMeetingRoom", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.ALL_VALUE)
	public ResponseEntity<String> addMeetingRoom(
			@RequestBody(required= true) String roomName
			)
	{
		return ResponseEntity.ok(register.addRoom(roomName));
	}
	
	@PostMapping(value="/availableRooms", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<String>> getAvailableRoom (
			@Valid @RequestBody(required= true) AvailableRequest request
			) throws Exception
	{
		
		return ResponseEntity.ok(available.getAvailableRooms(request));
	}
	
	@GetMapping(value="/getBookedRoomsDetails")
	public ResponseEntity<List<RoomBookingDetailsReponse>> getBookedRoomsDetails()
	{
		return ResponseEntity.ok(available.getBookedRoomsDetail());
	}
	
	@PostMapping(value="/availableUser", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<String>> getAvailableUser(
			@Valid @RequestBody(required= true) AvailableRequest request
			) throws Exception
	{
		
		return ResponseEntity.ok(available.getAvailableUsers(request));
	}
	
	@GetMapping(value="/getBusyUserDetails")
	public ResponseEntity<List<UserBookingDetailsReponse>> getBookedUserDetails()
	{
		return ResponseEntity.ok(available.getBusyUsersDetail());
	}
	
	@PostMapping(value = "/oneToOneMeeting", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<MeetingResponse> schduleOneToOne(
			@Valid @RequestBody(required = true) StandaloneMeetingRequest request)
	{
		return  ResponseEntity.ok(meeting.oneToOneMeetingScheduler(request));
	}
	
	@PostMapping(value = "/roomMeeting", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<MeetingResponse> schduleRoomMeeting(
			@Valid @RequestBody(required = true) RoomMeetingRequest request)
	{
		return  ResponseEntity.ok(meeting.roomMeetingScheduler(request));
	}
}
