package com.util.exception;

public class CustomException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomException(Exception ex, String message)
	{
		super(message+" : "+ ex.getMessage());
	}
}
