package com.util.exception;

import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionController {
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ExceptionResponse> handleGlobalException(Exception exception)
	{
		return new ResponseEntity<>
		(ExceptionResponse.builder().errorMessage("We are facing some issue due to :: "+exception.getMessage()).build(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ExceptionResponse> handleGlobalException(MethodArgumentNotValidException exception)
	{
		String errorMessage = exception.getBindingResult().getFieldErrors().stream()
	            .map(error -> error.getField() + ": " + error.getDefaultMessage())
	            .collect(Collectors.joining(", "));
		return new ResponseEntity<>
		(ExceptionResponse.builder().errorMessage(errorMessage).build(),
				HttpStatus.BAD_REQUEST);
	} 

}
