package com.util.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.util.model.entity.MeetingUserEntity;

@Repository
public interface MeetingUserRepository extends JpaRepository<MeetingUserEntity, Long> {

	@Query("SELECT mu.userName FROM MeetingUserEntity mu WHERE mu.meetingId = :meetingId")
	List<String> findUserNameByMeetingId(@Param("meetingId") Long meetingId);
}
