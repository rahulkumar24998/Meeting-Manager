package com.util.persistence;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.util.model.entity.SlotRegistrationEntity;

@Repository
public interface SlotRegistrationRepository extends JpaRepository<SlotRegistrationEntity, Long> {

	@Query("SELECT s.roomId FROM SlotRegistrationEntity s "
			+ "WHERE s.date = :date AND ((:inTime >= s.inTime and :inTime < s.outTime) "
			+ "or (:outTime > s.inTime and :outTime <=s.outTime)"
			+ " or (s.inTime>= :inTime and s.inTime<:outTime))")
	List<Long> findRoomIdByDateAndInTimeAndOutTime(@Param("date") LocalDate date, @Param("inTime") LocalTime inTime,
			@Param("outTime") LocalTime outTime);
	
	@Query("SELECT s.id FROM SlotRegistrationEntity s "
			+ "WHERE s.date = :date AND ((:inTime >= s.inTime and :inTime < s.outTime) "
			+ "or (:outTime > s.inTime and :outTime <=s.outTime)"
			+ " or (s.inTime>= :inTime and s.inTime<:outTime))")
	List<Long> findIdByDateAndInTimeAndOutTime(@Param("date") LocalDate date, @Param("inTime") LocalTime inTime,
			@Param("outTime") LocalTime outTime);
	
	  @Query("SELECT s FROM SlotRegistrationEntity s WHERE s.date >= :date")
	    List<SlotRegistrationEntity> findByDateGreaterThanEqual(@Param("date") LocalDate date);
}
