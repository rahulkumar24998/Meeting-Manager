package com.util.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.util.model.entity.RoomRegistrationEntity;
@Repository
public interface RoomRegistrationRepository extends JpaRepository<RoomRegistrationEntity, Long>{

	RoomRegistrationEntity findByRoomName(String roomName);
	
	@Query("SELECT r.roomName FROM RoomRegistrationEntity r WHERE r.id = :id")
	String findRoomNameById(@Param("id") Long id);
	
	@Query("SELECT r.id FROM RoomRegistrationEntity r WHERE r.roomName = :roomName")
	Long findIdByRoomName(@Param("roomName") String roomName);
}
