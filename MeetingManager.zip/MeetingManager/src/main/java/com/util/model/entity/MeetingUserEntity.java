package com.util.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "meeting_user_relation_table")
public class MeetingUserEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sr")
	private Long id;
	@Column(name = "user_name")
	private String userName;
	@Column(name = "meeting_id")
	private Long meetingId;
}

/**
Create table meeting_user_relation_table
(
sr bigserial Primary Key,
user_name character varying,
meeting_id bigint
)
*/