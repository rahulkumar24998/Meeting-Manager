package com.util.model.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "slot_registration_table")
public class SlotRegistrationEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "meeting_id")
	private Long id;
	@Column(name = "date_of_meeting")
	private LocalDate date;
	@Column(name = "in_time")
	private LocalTime inTime;
	@Column(name = "out_time")
	private LocalTime outTime;
	@Column(name = "room_id")
	private Long roomId;
}

/**
create table slot_registration_table
(
meeting_id bigserial Primary Key,
in_time time(0) without time zone,
out_time time(0) without time zone,
room_id bigint,
date_of_meeting timestamp without time zone
)
*/