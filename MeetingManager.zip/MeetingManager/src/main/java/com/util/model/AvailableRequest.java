package com.util.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AvailableRequest {

	@NotNull(message = "Date is required")
	@FutureOrPresent(message = "Past Date not allowed")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate date;
	@NotNull(message = "In Time is Required")
	@DateTimeFormat(pattern = "HH:mm")
	private LocalTime inTime;
	@NotNull(message = "Out Time is Required")
	@DateTimeFormat(pattern = "HH:mm")
	private LocalTime outTime;

	@AssertTrue(message = "In time must be less than out time")
    public boolean isTimeValid() {
        return inTime.isBefore(outTime);
    }
}
