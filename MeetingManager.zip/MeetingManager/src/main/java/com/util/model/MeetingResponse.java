package com.util.model;

import lombok.Data;

@Data
public class MeetingResponse {

	private Boolean success;
	private String message;
	private Long meetingId;
}
