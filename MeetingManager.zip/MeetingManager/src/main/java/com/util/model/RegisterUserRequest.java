package com.util.model;

import lombok.Data;

@Data
public class RegisterUserRequest {

	private String userName;
	private String password;
}
