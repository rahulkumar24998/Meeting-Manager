package com.util.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class RoomMeetingRequest {

	@NotNull(message = "Date is required")
	@FutureOrPresent(message = "Past Date not allowed")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate date;
	@NotNull(message = "In Time is Required")
	@DateTimeFormat(pattern = "HH:mm")
	private LocalTime inTime;
	@NotNull(message = "Out Time is Required")
	@DateTimeFormat(pattern = "HH:mm")
	private LocalTime outTime;
	@NotNull(message = "Organizer Name is required")
	private String organizer;
	@NotNull(message = "RoomName is required")
	private String roomName;
	@NotNull(message = "Add Users to meeting")
	@NotEmpty(message = "Add Users to meeting")
	private List<String> userList;
	
	@AssertTrue(message = "In time must be less than out time")
    public boolean isTimeValid() {
        return inTime.isBefore(outTime);
    }
	
}
